import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analysis-status',
  templateUrl: './analysis-status.component.html',
  styleUrls: ['./analysis-status.component.css']
})
export class AnalysisStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
