import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analysis-search',
  templateUrl: './analysis-search.component.html',
  styleUrls: ['./analysis-search.component.css']
})
export class AnalysisSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
