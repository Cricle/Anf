import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-giant-screen',
  templateUrl: './giant-screen.component.html',
  styleUrls: ['./giant-screen.component.css']
})
export class GiantScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
